
  # 카드게임

  This is a code bundle for 카드게임. The original project is available at https://www.figma.com/design/p8c9KAiN66uSWU3cYBkXSI/%EC%B9%B4%EB%93%9C%EA%B2%8C%EC%9E%84.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  